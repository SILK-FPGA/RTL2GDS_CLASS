// --- RTL Files ---

/home/huyatieo/ctwsemi-data/ips/TinyTDC/rtl/sky130_fd_sc_hd.v


/home/huyatieo/ctwsemi-data/ips/TinyTDC/rtl/tinytdc.nl.v


// --- Testbench Files ---
/home/huyatieo/ctwsemi-data/ips/TinyTDC/tb/tb_postlayout.v

// --- Testcase Files ---
// Các testcase có thể được include từ testbench/package.
