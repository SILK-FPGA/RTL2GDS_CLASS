#!/usr/bin/env python3
"""Make a CVC-compatible copy of a LibreLane SDF by dropping only
INTERCONNECT arcs that target top-level rd_data_o[1:7].

These SDF arcs may fail in OSS CVC 7.00b with ERROR [1509] despite
correct internal gate/cell timing. This script does NOT edit the source
file and does NOT touch internal START/STOP delay paths.

Usage: python3 patch_cvc_sdf.py input.sdf output.sdf
"""
from pathlib import Path
import re
import sys

if len(sys.argv) != 3:
    raise SystemExit("Usage: python3 patch_cvc_sdf.py input.sdf output.sdf")
source, destination = map(Path, sys.argv[1:])
if source.resolve() == destination.resolve():
    raise SystemExit("Input and output paths must differ; original SDF is preserved")
if not source.is_file():
    raise SystemExit(f"Input SDF not found: {source}")
text = source.read_text(encoding="utf-8")
# Keep the transformation scoped to output bus bits confirmed problematic
# in the user's CVC log. Do not edit clock/START/STOP or any cell IOPATH.
pattern = re.compile(r"(?m)^\s*\(INTERCONNECT\s+\S+\s+rd_data_o\[([1-7])\]\s+[^\r\n]*\)\s*$")
removed = []

def omit(match):
    removed.append(int(match.group(1)))
    return ""

modified = pattern.sub(omit, text)
if sorted(removed) != list(range(1,8)):
    raise SystemExit(f"Expected exactly output bits 1..7, found: {sorted(removed)}. Not writing output. Inspect SDF.")
if "u_start_line" not in modified or "u_stop_line" not in modified:
    raise SystemExit("Unexpected SDF structure: START/STOP instances not found")
if "IOPATH" not in modified:
    raise SystemExit("Unexpected SDF structure: no IOPATH arcs")
destination.parent.mkdir(parents=True, exist_ok=True)
destination.write_text(modified, encoding="utf-8")
print(f"Created: {destination} ({len(removed)} output-only arcs omitted: bits {sorted(removed)})")
print("All internal IOPATH and START/STOP interconnect records retained.")
