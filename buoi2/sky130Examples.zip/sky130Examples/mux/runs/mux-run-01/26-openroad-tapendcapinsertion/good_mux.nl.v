module good_mux (i0,
    i1,
    sel,
    y);
 input i0;
 input i1;
 input sel;
 output y;


 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_0_Left_1 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_0_Right_0 ();
 sky130_fd_sc_hd__mux2_1 _0_ (.A0(i0),
    .A1(i1),
    .S(sel),
    .X(y));
endmodule
