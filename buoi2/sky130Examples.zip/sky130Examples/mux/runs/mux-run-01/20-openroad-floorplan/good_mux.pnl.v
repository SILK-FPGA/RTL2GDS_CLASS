module good_mux (i0,
    i1,
    sel,
    y);
 input i0;
 input i1;
 input sel;
 output y;

 wire VPWR;
 wire VGND;

 sky130_fd_sc_hd__mux2_1 _0_ (.A0(i0),
    .A1(i1),
    .S(sel),
    .VGND(VGND),
    .VNB(VGND),
    .VPB(VPWR),
    .VPWR(VPWR),
    .X(y));
endmodule
