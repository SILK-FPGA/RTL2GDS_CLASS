`timescale 1ns/1ps
`default_nettype none

module fa_tb;
    reg        clk;
    reg        rst_n;
    reg  [7:0] ui_in;
    reg  [7:0] uio_in;
    wire [7:0] uo_out;
    wire [7:0] uio_out;
    wire [7:0] uio_oe;

    integer vector;
    reg [2:0] previous_input;
    reg [1:0] expected;

    fa_lab dut (
        .ui_in   (ui_in),
        .uo_out  (uo_out),
        .uio_in  (uio_in),
        .uio_out (uio_out),
        .uio_oe  (uio_oe),
        .clk     (clk),
        .rst_n   (rst_n)
    );

    initial clk = 1'b0;
    always #10 clk = ~clk; // 20 ns period = 50 MHz

    task check_result;
        input [2:0] value;
        begin
            expected = value[0] + value[1] + value[2];
            if (uo_out[1:0] !== expected) begin
                $display("FAIL: a=%0d b=%0d cin=%0d expected={cout,sum}=%02b got=%02b",
                         value[0], value[1], value[2], expected, uo_out[1:0]);
                $fatal(1);
            end
            $display("PASS: a=%0d b=%0d cin=%0d -> cout=%0d sum=%0d",
                     value[0], value[1], value[2], uo_out[1], uo_out[0]);
        end
    endtask

    initial begin
        $dumpfile("fa_tb.vcd");
        $dumpvars(0, fa_tb);

        rst_n  = 1'b0;
        ui_in  = 8'h00;
        uio_in = 8'h00;

        repeat (2) @(posedge clk);
        @(negedge clk);
        rst_n = 1'b1;

        previous_input = 3'b000;
        for (vector = 0; vector < 8; vector = vector + 1) begin
            @(negedge clk);
            ui_in[2:0] = vector[2:0];
            @(posedge clk);
            #1;
            if (vector == 0)
                check_result(3'b000);
            else
                check_result(previous_input);
            previous_input = vector[2:0];
        end
        @(negedge clk);
        ui_in[2:0] = 3'b000;
        @(posedge clk);
        #1;
        check_result(previous_input);

        if (uio_out !== 8'h00 || uio_oe !== 8'h00)
            $fatal(1, "Unused bidirectional outputs must remain disabled");

        $display("ALL FULL-ADDER TESTS PASSED");
        $finish;
    end
endmodule

`default_nettype wire
