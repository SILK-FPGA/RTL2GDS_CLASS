module fa_lab (clk,
    ena,
    rst_n,
    ui_in,
    uio_in,
    uio_oe,
    uio_out,
    uo_out);
 input clk;
 input ena;
 input rst_n;
 input [7:0] ui_in;
 input [7:0] uio_in;
 output [7:0] uio_oe;
 output [7:0] uio_out;
 output [7:0] uo_out;

 wire _00_;
 wire _01_;
 wire _02_;
 wire _03_;
 wire _04_;
 wire _05_;
 wire _06_;
 wire _07_;
 wire _08_;
 wire _09_;
 wire a_q;
 wire b_q;
 wire cin_q;
 wire cout_q;
 wire sum_q;

 sky130_fd_sc_hd__and2_2 _10_ (.A(ui_in[0]),
    .B(rst_n),
    .X(_00_));
 sky130_fd_sc_hd__and2_2 _11_ (.A(rst_n),
    .B(ui_in[1]),
    .X(_01_));
 sky130_fd_sc_hd__and2_2 _12_ (.A(rst_n),
    .B(ui_in[2]),
    .X(_02_));
 sky130_fd_sc_hd__nand2_2 _13_ (.A(a_q),
    .B(b_q),
    .Y(_05_));
 sky130_fd_sc_hd__or2_2 _14_ (.A(a_q),
    .B(b_q),
    .X(_06_));
 sky130_fd_sc_hd__a21o_2 _15_ (.A1(_05_),
    .A2(_06_),
    .B1(cin_q),
    .X(_07_));
 sky130_fd_sc_hd__nand3_2 _16_ (.A(cin_q),
    .B(_05_),
    .C(_06_),
    .Y(_08_));
 sky130_fd_sc_hd__and3_2 _17_ (.A(rst_n),
    .B(_07_),
    .C(_08_),
    .X(_03_));
 sky130_fd_sc_hd__a21o_2 _18_ (.A1(a_q),
    .A2(b_q),
    .B1(cin_q),
    .X(_09_));
 sky130_fd_sc_hd__and3_2 _19_ (.A(rst_n),
    .B(_06_),
    .C(_09_),
    .X(_04_));
 sky130_fd_sc_hd__dfxtp_2 _20_ (.CLK(clk),
    .D(_00_),
    .Q(a_q));
 sky130_fd_sc_hd__dfxtp_2 _21_ (.CLK(clk),
    .D(_01_),
    .Q(b_q));
 sky130_fd_sc_hd__dfxtp_2 _22_ (.CLK(clk),
    .D(_02_),
    .Q(cin_q));
 sky130_fd_sc_hd__dfxtp_2 _23_ (.CLK(clk),
    .D(_03_),
    .Q(sum_q));
 sky130_fd_sc_hd__dfxtp_2 _24_ (.CLK(clk),
    .D(_04_),
    .Q(cout_q));
 sky130_fd_sc_hd__conb_1 _25_ (.LO(uio_oe[0]));
 sky130_fd_sc_hd__conb_1 _26_ (.LO(uio_oe[1]));
 sky130_fd_sc_hd__conb_1 _27_ (.LO(uio_oe[2]));
 sky130_fd_sc_hd__conb_1 _28_ (.LO(uio_oe[3]));
 sky130_fd_sc_hd__conb_1 _29_ (.LO(uio_oe[4]));
 sky130_fd_sc_hd__conb_1 _30_ (.LO(uio_oe[5]));
 sky130_fd_sc_hd__conb_1 _31_ (.LO(uio_oe[6]));
 sky130_fd_sc_hd__conb_1 _32_ (.LO(uio_oe[7]));
 sky130_fd_sc_hd__conb_1 _33_ (.LO(uio_out[0]));
 sky130_fd_sc_hd__conb_1 _34_ (.LO(uio_out[1]));
 sky130_fd_sc_hd__conb_1 _35_ (.LO(uio_out[2]));
 sky130_fd_sc_hd__conb_1 _36_ (.LO(uio_out[3]));
 sky130_fd_sc_hd__conb_1 _37_ (.LO(uio_out[4]));
 sky130_fd_sc_hd__conb_1 _38_ (.LO(uio_out[5]));
 sky130_fd_sc_hd__conb_1 _39_ (.LO(uio_out[6]));
 sky130_fd_sc_hd__conb_1 _40_ (.LO(uio_out[7]));
 sky130_fd_sc_hd__conb_1 _41_ (.LO(uo_out[2]));
 sky130_fd_sc_hd__conb_1 _42_ (.LO(uo_out[3]));
 sky130_fd_sc_hd__conb_1 _43_ (.LO(uo_out[4]));
 sky130_fd_sc_hd__conb_1 _44_ (.LO(uo_out[5]));
 sky130_fd_sc_hd__conb_1 _45_ (.LO(uo_out[6]));
 sky130_fd_sc_hd__conb_1 _46_ (.LO(uo_out[7]));
 sky130_fd_sc_hd__buf_2 _47_ (.A(sum_q),
    .X(uo_out[0]));
 sky130_fd_sc_hd__buf_2 _48_ (.A(cout_q),
    .X(uo_out[1]));
endmodule
