# Registered Full-Adder — Tiny Tapeout SKY130 1x1

This is the 1x1 version of the CTW SEMI/OpenROAD teaching lab.

## Geometry

- Official Tiny Tapeout SKY130 template: `tt_block_1x1_pg.def`
- `DIEAREA`: `0 0 161000 111520` database units
- LibreLane `DIE_AREA`: `0 0 161 111.52` micrometres
- 43 Tiny Tapeout signal pins on `met4`
- Special power nets: `VPWR` and `VGND`

Do not mix this DEF with the 2x2 die area. The two configuration entries must
always be changed as a pair:

```json
"DIE_AREA": "0 0 161 111.52",
"FP_DEF_TEMPLATE": "dir::tt_block_1x1_pg.def"
```

Run order: syntax check, RTL simulation, synthesis, floorplan, PDN, placement,
CTS, routing, parasitic extraction, STA, DRC/LVS and final GDS.

