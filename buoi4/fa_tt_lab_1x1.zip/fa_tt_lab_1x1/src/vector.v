module vector(
    output reg a,
    input wire i1,
    input wire clk,
    output reg b
);

always @(posedge clk)
begin
    a <= i1;
    b <= a;
end
endmodule